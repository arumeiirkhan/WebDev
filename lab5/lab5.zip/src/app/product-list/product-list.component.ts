import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {

  products = [
    {
      category: "Phones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hfe/hf7/62948389748766/apple-iphone-14-pro-128gb-fioletovyj-106363283-1.jpg',
      name: 'Смартфон Apple iPhone 14 Pro 128Gb фиолетовый',
      description: 'технология NFC: Да\n' +
        'тип экрана: OLED, Super Retina XDR display с возможностью постоянной работы\n' +
        'диагональ: 6.1 дюйм\n' +
        'размер оперативной памяти:6 ГБ\n' +
        'процессор: 6-ядерный Apple A16 Bionic\n',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/apple-iphone-14-pro-128gb-fioletovyi-106363283/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hfe/hf7/62948389748766/apple-iphone-14-pro-128gb-fioletovyj-106363283-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf4/h20/63074367406110/apple-iphone-14-pro-128gb-fioletovyj-106363283-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h03/h50/63074367635486/apple-iphone-14-pro-128gb-fioletovyj-106363283-4.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h18/h35/63074367864862/apple-iphone-14-pro-128gb-fioletovyj-106363283-5.jpg']
      ,price: 571096 , likes: 30
    },
    {
      category: "Phones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h87/h60/61658891714590/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-1.jpg',
      name: 'Смартфон Samsung Galaxy Z Fold4 12 ГБ/512 ГБ черный',
      description: 'технология NFC: Да\n' +
        'цвет: черный\n' +
        'диагональ: 7.6 дюйм\n' +
        'размер оперативной памяти: 12 ГБ\n' +
        'процессор: 8-ядерный Qualcomm Snapdragon 8 Gen 1\n' +
        'объем встроенной памяти: 512 ГБ\n',
      rating: 3.6,
      url: 'https://kaspi.kz/shop/p/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-podarok-106036420/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h01/h8c/61658913931294/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hbd/h42/61658892632094/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-5.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/ha9/h5d/61658892861470/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-6.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf9/hba/61658914160670/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-4.jpg']
      ,price: 1099880, likes: 2
    },
    {
      category: "Phones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h4b/hde/62178742403102/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-1.jpg',
      name: 'Смартфон Samsung Galaxy Z Flip4 8 ГБ/128 ГБ серый',
      description: 'технология NFC: Да\n' +
        'цвет: серый\n' +
        'тип экрана: AMOLED, сенсорный\n' +
        'процессор: 8-ядерный Qualcomm Snapdragon 8 Gen 1\n' +
        'объем встроенной памяти: 128 ГБ\n' ,
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/samsung-galaxy-z-flip4-8-gb-128-gb-seryi-106305928/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h4b/hde/62178742403102/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6f/hf2/62178742861854/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h24/h56/62178743320606/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h46/hd0/62178744238110/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-5.jpg']
      ,price: 530000, likes: 18
    },
    {
      category: "Phones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hc9/h32/34429815324702/xiaomi-mi-11-ultra-12-512gb-belyj-101846776-1-Container.jpg',
      name: 'Смартфон Xiaomi Mi 11 Ultra 12/512Gb белый',
      description: 'технология NFC: Да\n' +
        'цвет: серый\n' +
        'тип экрана: AMOLED, сенсорный\n' +
        'процессор: 8-ядерный Qualcomm Snapdragon 8 Gen 1\n' +
        'объем встроенной памяти: 128 ГБ\n' ,
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/xiaomi-mi-11-ultra-12-512gb-belyi-101846776/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hc9/h32/34429815324702/xiaomi-mi-11-ultra-12-512gb-belyj-101846776-1-Container.jpg']
      ,price: 437000, likes: 15
    },{
      category: "Phones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h12/h2e/62179048095774/samsung-galaxy-z-flip4-8-gb-256-gb-fioletovyj-smart-casy-samsung-galaxy-watch-4-106306207-1.jpg',
      name: 'Смартфон Samsung Galaxy Z Flip4 8 ГБ/256 ГБ ф',
      description: 'технология NFC: Да\n' +
        'цвет: серый\n' +
        'тип экрана: AMOLED, сенсорный\n' +
        'процессор: 8-ядерный Qualcomm Snapdragon 8 Gen 1\n' +
        'объем встроенной памяти: 128 ГБ\n' ,
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/samsung-galaxy-z-flip4-8-gb-128-gb-seryi-106305928/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h12/h2e/62179048095774/samsung-galaxy-z-flip4-8-gb-256-gb-fioletovyj-smart-casy-samsung-galaxy-watch-4-106306207-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hee/hd5/62179049930782/samsung-galaxy-z-flip4-8-gb-256-gb-fioletovyj-smart-casy-samsung-galaxy-watch-4-106306207-5.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h8a/hf9/62179048554526/samsung-galaxy-z-flip4-8-gb-256-gb-fioletovyj-smart-casy-samsung-galaxy-watch-4-106306207-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hfb/hea/62179049472030/samsung-galaxy-z-flip4-8-gb-256-gb-fioletovyj-smart-casy-samsung-galaxy-watch-4-106306207-4.jpg']
      ,price: 599700, likes: 30
    },
    {
      category: "Watches",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h1a/h69/63158968057886/apple-watch-series-8-41-mm-cernyj-106362847-1.jpg',
      name: 'Смарт-часы Apple Watch Series 8 45 мм Aluminum черный',
      description: 'поддержка платформ: iOS\n' +
        'материал корпуса: алюминий\n' +
        'цвет корпуса: черный\n' +
        'технология экрана: OLED\n' +
        'объем встроенной памяти: 32 Гб\n' +
        'интерфейсы: Bluetooth, ,Wi-Fi, ,NFC\n',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/apple-watch-series-8-45-mm-aluminum-chernyi-106362847/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h1a/h69/63158968057886/apple-watch-series-8-41-mm-cernyj-106362847-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h77/hbb/63158968418334/apple-watch-series-8-41-mm-cernyj-106362847-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h0d/h91/62281248571422/apple-watch-series-8-41-mm-cernyj-106362847-3.jpg']
      ,price: 229305, likes: 5
    },
    {
      category: "Watches",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6c/h85/62047597592606/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-1-Container.jpg',
      name: 'Смарт-часы Samsung Galaxy Watch 4 черный',
      description: 'поддержка платформ: Android\n' +
        'материал корпуса: алюминий\n' +
        'цвет корпуса: черный\n' +
        'интерфейсы: Bluetooth, ,NFC',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/samsung-galaxy-watch-4-classic-sm-r890nzkacis-46-mm-chernyi-chernyi-102170938/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6c/h85/62047597592606/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf2/h5e/62047597821982/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h7b/h7b/62047598051358/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hac/h4d/62047598510110/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-4.jpg']
      ,price: 90890, likes: 106
    },
    {
      category: "Watches",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5f/h83/62047586975774/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-1.jpg',
      name: 'Смарт-часы Kieslect Smart Calling Whatch Kr черный',
      description: 'поддержка платформ: Android, ,iOS\n' +
        'материал корпуса: металл\n' +
        'цвет корпуса: черный\n' +
        'интерфейсы: Bluetooth\n' +
        'время работы: 9 дней/ при активном режиме - до 2 дней',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/kieslect-smart-calling-whatch-kr-chernyi-105772460/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5f/h83/62047586975774/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h0f/h45/62047587336222/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hff/h15/62047587565598/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h74/h99/52423842725918/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-4.jpg']
      ,price: 34988, likes: 29
    },
    {
      category: "Watches",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/he2/h80/48552105803806/garmin-fenix-7s-sapphire-solar-bordovyj-seryj-103579757-1.jpg',
      name: 'Смарт-часы Garmin Fenix 7S Sapphire Solar бордовый',
      description: 'поддержка платформ: iOS\n' +
        'материал корпуса: алюминий\n' +
        'цвет корпуса: черный\n' +
        'технология экрана: OLED\n' +
        'объем встроенной памяти: 32 Гб\n' +
        'интерфейсы: Bluetooth, ,Wi-Fi, ,NFC\n',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/garmin-fenix-7s-sapphire-solar-bordovyi-seryi-103579757/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/he2/h80/48552105803806/garmin-fenix-7s-sapphire-solar-bordovyj-seryj-103579757-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hcb/h2c/48552106262558/garmin-fenix-7s-sapphire-solar-bordovyj-seryj-103579757-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5c/h9c/48552106721310/garmin-fenix-7s-sapphire-solar-bordovyj-seryj-103579757-3.jpg',
      'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h51/h11/48552107180062/garmin-fenix-7s-sapphire-solar-bordovyj-seryj-103579757-4.jpg']
      ,price: 478999, likes: 5
    },{
      category: "Watches",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h44/h7e/31963329363998/casio-ae-1200whd-1avef-silver-21409364-1-Container.jpg',
      name: 'Часы CASIO AE-1200WHD-1AVEF серебристый',
      description: 'поддержка платформ: iOS\n' +
        'материал корпуса: алюминий\n' +
        'цвет корпуса: черный\n' +
        'технология экрана: OLED\n' +
        'объем встроенной памяти: 32 Гб\n' +
        'интерфейсы: Bluetooth, ,Wi-Fi, ,NFC\n',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/casio-ae-1200whd-1avef-serebristyi-21409364/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h44/h7e/31963329363998/casio-ae-1200whd-1avef-silver-21409364-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h21/h81/31963345223710/casio-ae-1200whd-1avef-silver-21409364-3-Container.jpg']
      ,price: 19701, likes: 70
    },
    {
      category: "HeadPhones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/ha6/h0c/33518056079390/apple-airpods-max-cernyj-100950846-1-Container.jpg',
      name: 'Наушники Apple AirPods Max черный',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Да\n' +
        'микрофон: Да',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/apple-airpods-max-chernyi-100950846/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/ha6/h0c/33518056079390/apple-airpods-max-cernyj-100950846-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h58/h10/33518228701214/apple-airpods-max-cernyj-100950846-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h1f/hec/33518234402846/apple-airpods-max-cernyj-100950846-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h97/h88/46659778510878/apple-airpods-max-cernyj-100950846-4.jpg']
      ,price: 347345, likes: 35
    },
    {
      category:"HeadPhones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3d/h52/33973207105566/jbl-tune-510bt-belyj-101420096-1-Container.jpg',
      name: 'Наушники JBL Tune 510BT белый',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Нет\n' +
        'микрофон: Да',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/jbl-tune-510bt-belyi-101420096/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3d/h52/33973207105566/jbl-tune-510bt-belyj-101420096-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3e/h06/33973209759774/jbl-tune-510bt-belyj-101420096-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h99/he7/33973212381214/jbl-tune-510bt-belyj-101420096-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/had/h60/33973214969886/jbl-tune-510bt-belyj-101420096-4-Container.jpg']
      ,price: 24400, likes: 111
    },
    {
      category: "HeadPhones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6a/hd9/44876126093342/marshall-major-iv-102138144-3-Container.jpg',
      name: 'Наушники Marshall Major IV черный Marshall Major IV lux',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Нет\n' +
        'микрофон: Да',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/marshall-major-iv-chernyi-102138144/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6a/hd9/44876126093342/marshall-major-iv-102138144-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h17/h84/44876124127262/marshall-major-iv-102138144-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h2a/h24/44876125110302/marshall-major-iv-102138144-2-Container.jpg']
      ,price: 129890, likes: 67
    },
    {
      category: "HeadPhones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hd3/h42/47952664035358/bang-olufsen-beoplay-h95-seryj-103292154-1.jpg',
      name: 'Наушники Bang & Olufsen BeoPlay H95 серый',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Нет\n' +
        'микрофон: Да',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/bang-olufsen-beoplay-h95-seryi-103292154/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hd3/h42/47952664035358/bang-olufsen-beoplay-h95-seryj-103292154-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hbf/h5d/47952664264734/bang-olufsen-beoplay-h95-seryj-103292154-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h8e/hd9/47952664494110/bang-olufsen-beoplay-h95-seryj-103292154-3.jpg']
      ,price: 539990, likes: 67
    },
    {
      category: "HeadPhones",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h8e/h6a/68868946690078/beoplay-h95-chestnut-108844218-3.jpg',
      name: 'Наушники Bang & Olufsen Beoplay H95 коричневый',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Нет\n' +
        'микрофон: Да',
      rating: 4.9,
      url: 'https://kaspi.kz/shop/p/bang-olufsen-beoplay-h95-korichnevyi-108844218/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h8e/h6a/68868946690078/beoplay-h95-chestnut-108844218-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6a/h5f/68868946165790/beoplay-h95-chestnut-108844218-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h4c/h3e/68868945641502/beoplay-h95-chestnut-108844218-1.jpg']
      ,price: 539990, likes: 67
    },
    {
      category:"Speakers",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5c/h05/46546975817758/yandeks-novaya-stantsiya-mini-s-chasami-seryi-102580001-1.jpg',
      name: 'Умная колонка Яндекс Станция Мини 2 с часами белый',
      description: 'суммарная мощность: 10 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Алиса\n' +
        'поддерживаемый язык: русский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 3.4,
      url: 'https://kaspi.kz/shop/p/jandeks-stantsija-mini-2-s-chasami-belyi-102580001/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5c/h05/46546975817758/yandeks-novaya-stantsiya-mini-s-chasami-seryi-102580001-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h31/h79/46546976374814/yandeks-novaya-stantsiya-mini-s-chasami-seryi-102580001-2.jpg']
      ,price: 43730, likes: 74
    },
    {
      category:"Speakers",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf3/hd3/51046001246238/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-1.jpg',
      name: 'Умная колонка Яндекс Станция Макс синий',
      description: 'суммарная мощность: 65 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Алиса\n' +
        'поддерживаемый язык: русский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 4.7,
      url: 'https://kaspi.kz/shop/p/jandeks-stantsija-maks-sinii-101165296/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf3/hd3/51046001246238/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf9/h96/51046001639454/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hd7/h54/51046001836062/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-4.jpg']
      ,price: 165856, likes: 77
    },
    {
      category:"Speakers",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h19/h04/52127953616926/apple-homepod-mini-cernyj-100983175-1-Container.jpg',
      name: 'Умная колонка Apple HomePod mini черный',
      description: 'суммарная мощность: 20 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Apple Siri\n' +
        'поддерживаемый язык: английский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 5.0,
      url: 'https://kaspi.kz/shop/p/apple-homepod-mini-chernyi-100983175/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h19/h04/52127953616926/apple-homepod-mini-cernyj-100983175-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hca/hcc/52127953846302/apple-homepod-mini-cernyj-100983175-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hdb/hb7/51081275244574/apple-homepod-mini-cernyj-100983175-3-Container.jpg']
      ,price: 85860, likes: 19
    },
    {
      category:"Speakers",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h49/h38/32802853290014/bang-olufsen-beosound-balance-bezevyj-100496040-1.jpg',
      name: 'Портативная колонка Bang & Olufsen Beosound',
      description: 'суммарная мощность: 20 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Apple Siri\n' +
        'поддерживаемый язык: английский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 5.0,
      url: 'https://kaspi.kz/shop/p/bang-olufsen-beosound-balance-bezhevyi-100496040/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h49/h38/32802853290014/bang-olufsen-beosound-balance-bezevyj-100496040-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hbf/h00/32802861875230/bang-olufsen-beosound-balance-bezevyj-100496040-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf0/h46/32802870394910/bang-olufsen-beosound-balance-bezevyj-100496040-3.jpg']
      ,price: 1059990, likes: 19
    },
    {
      category:"Speakers",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h27/h56/31576274337822/bang-olufsen-beoplay-a9-smoked-oak-11500521-1.jpg',
      name: 'Портативная колонка Bang & Olufsen BeoPlay A9 Smoked Oak',
      description: 'суммарная мощность: 20 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Apple Siri\n' +
        'поддерживаемый язык: английский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 5.0,
      url: 'https://kaspi.kz/shop/p/bang-olufsen-beoplay-a9-smoked-oak-11500521/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h27/h56/31576274337822/bang-olufsen-beoplay-a9-smoked-oak-11500521-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hb9/h88/31576276402206/bang-olufsen-beoplay-a9-smoked-oak-11500521-2.jpg']
      ,price: 1980000, likes: 19
    },
  ];

  categories = [
    {name: "Phones"},
    {name: "Watches"},
    {name: "HeadPhones"},
    {name: "Speakers"},

  ]


  selectedCategory!: string;
  filteredProducts!: any[];

  ngOnInit() {
    this.filterProducts();
  }

  categorySelected(category: string) {
    this.selectedCategory = category;
    this.filterProducts();
  }

  filterProducts() {
    if (this.selectedCategory) {
      this.filteredProducts = this.products.filter(product => product.category === this.selectedCategory);
    } else {
      this.filteredProducts = this.products;
    }
  }


}
