import { Component } from '@angular/core';
import { Product } from '../app.component';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  products: Product[] = [
    {
      no: 1,
      id: "apple-iphone-14-pro-128gb-fioletovyi-106363283/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hfe/hf7/62948389748766/apple-iphone-14-pro-128gb-fioletovyj-106363283-1.jpg',
      name: 'Смартфон Apple iPhone 14 Pro 128Gb фиолетовый',
      description: 'технология NFC: Да\n' +
        'тип экрана: OLED, Super Retina XDR display с возможностью постоянной работы\n' +
        'диагональ: 6.1 дюйм\n' +
        'размер оперативной памяти: 6 ГБ\n' +
        'процессор: 6-ядерный Apple A16 Bionic\n' +
        'объем встроенной памяти: 128 ГБ\n' +
        'емкость аккумулятора: 3125мАч',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/apple-iphone-14-pro-128gb-fioletovyi-106363283/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hfe/hf7/62948389748766/apple-iphone-14-pro-128gb-fioletovyj-106363283-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf4/h20/63074367406110/apple-iphone-14-pro-128gb-fioletovyj-106363283-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h03/h50/63074367635486/apple-iphone-14-pro-128gb-fioletovyj-106363283-4.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h18/h35/63074367864862/apple-iphone-14-pro-128gb-fioletovyj-106363283-5.jpg']

    },
    {
      no: 2,
      id: "samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-podarok-106036420/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h87/h60/61658891714590/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-1.jpg',
      name: 'Смартфон Samsung Galaxy Z Fold4 12 ГБ/512 ГБ черный',
      description: 'технология NFC: Да\n' +
        'цвет: черный\n' +
        'тип экрана: Dynamic AMOLED 2X\n' +
        'диагональ: 7.6 дюйм\n' +
        'размер оперативной памяти: 12 ГБ\n' +
        'процессор: 8-ядерный Qualcomm Snapdragon 8 Gen 1\n' +
        'объем встроенной памяти: 512 ГБ\n' +
        'емкость аккумулятора: 4400 мАч',
      rating: 3.6,
      link: 'https://kaspi.kz/shop/p/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-podarok-106036420/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h01/h8c/61658913931294/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hbd/h42/61658892632094/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-5.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/ha9/h5d/61658892861470/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-6.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf9/hba/61658914160670/samsung-galaxy-z-fold4-12-gb-512-gb-chernyi-smart-chasy-samsung-galaxy-watch-4-classic-106036420-4.jpg']
    },
    {
      no: 3,
      id: "samsung-galaxy-z-flip4-8-gb-128-gb-seryi-106305928/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h4b/hde/62178742403102/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-1.jpg',
      name: 'Смартфон Samsung Galaxy Z Flip4 8 ГБ/128 ГБ серый',
      description: 'технология NFC: Да\n' +
        'цвет: серый\n' +
        'тип экрана: AMOLED, сенсорный\n' +
        'диагональ: 6.7 дюйм\n' +
        'размер оперативной памяти: 8 ГБ\n' +
        'процессор: 8-ядерный Qualcomm Snapdragon 8 Gen 1\n' +
        'объем встроенной памяти: 128 ГБ\n' +
        'емкость аккумулятора: 3700 мАч',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/samsung-galaxy-z-flip4-8-gb-128-gb-seryi-106305928/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h4b/hde/62178742403102/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6f/hf2/62178742861854/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h24/h56/62178743320606/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h46/hd0/62178744238110/samsung-galaxy-z-flip4-8-gb-128-gb-seryj-smart-casy-samsung-galaxy-watch-4-106305928-5.jpg']
    },
    {
      no: 4,
      id: "apple-watch-series-8-45-mm-aluminum-chernyi-106362847/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h1a/h69/63158968057886/apple-watch-series-8-41-mm-cernyj-106362847-1.jpg',
      name: 'Смарт-часы Apple Watch Series 8 45 мм Aluminum черный',
      description: 'поддержка платформ: iOS\n' +
        'материал корпуса: алюминий\n' +
        'цвет корпуса: черный\n' +
        'технология экрана: OLED\n' +
        'объем встроенной памяти: 32 Гб\n' +
        'интерфейсы: Bluetooth, ,Wi-Fi, ,NFC\n' +
        'время работы: в обычном режиме: 18 часов, в режиме энергосбережения: 36 часов',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/apple-watch-series-8-45-mm-aluminum-chernyi-106362847/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h1a/h69/63158968057886/apple-watch-series-8-41-mm-cernyj-106362847-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h77/hbb/63158968418334/apple-watch-series-8-41-mm-cernyj-106362847-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h0d/h91/62281248571422/apple-watch-series-8-41-mm-cernyj-106362847-3.jpg']

    },
    {
      no: 5,
      id: "samsung-galaxy-watch-4-classic-sm-r890nzkacis-46-mm-chernyi-chernyi-102170938/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6c/h85/62047597592606/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-1-Container.jpg',
      name: 'Смарт-часы Samsung Galaxy Watch 4 черный',
      description: 'поддержка платформ: Android\n' +
        'материал корпуса: алюминий\n' +
        'цвет корпуса: черный\n' +
        'интерфейсы: Bluetooth, ,NFC',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/samsung-galaxy-watch-4-classic-sm-r890nzkacis-46-mm-chernyi-chernyi-102170938/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6c/h85/62047597592606/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf2/h5e/62047597821982/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h7b/h7b/62047598051358/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hac/h4d/62047598510110/samsung-galaxy-watch-4-classic-sm-r890-cernyj-102170938-4.jpg']

    },
    {
      no: 6,
      id: "kieslect-smart-calling-whatch-kr-chernyi-105772460/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5f/h83/62047586975774/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-1.jpg',
      name: 'Смарт-часы Kieslect Smart Calling Whatch Kr черный',
      description: 'поддержка платформ: Android, ,iOS\n' +
        'материал корпуса: металл\n' +
        'цвет корпуса: черный\n' +
        'интерфейсы: Bluetooth\n' +
        'время работы: 9 дней/ при активном режиме - до 2 дней',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/kieslect-smart-calling-whatch-kr-chernyi-105772460/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5f/h83/62047586975774/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h0f/h45/62047587336222/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-2.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hff/h15/62047587565598/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h74/h99/52423842725918/xiaomi-kieslect-smart-calling-whatch-kr-chernyi-105772460-4.jpg']

    },
    {
      no: 7,
      id: "apple-airpods-max-chernyi-100950846/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/ha6/h0c/33518056079390/apple-airpods-max-cernyj-100950846-1-Container.jpg',
      name: 'Наушники Apple AirPods Max черный',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Да\n' +
        'микрофон: Да',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/apple-airpods-max-chernyi-100950846/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/ha6/h0c/33518056079390/apple-airpods-max-cernyj-100950846-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h58/h10/33518228701214/apple-airpods-max-cernyj-100950846-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h1f/hec/33518234402846/apple-airpods-max-cernyj-100950846-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h97/h88/46659778510878/apple-airpods-max-cernyj-100950846-4.jpg']

    },
    {
      no: 8,
      id: "jbl-tune-510bt-belyi-101420096/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3d/h52/33973207105566/jbl-tune-510bt-belyj-101420096-1-Container.jpg',
      name: 'Наушники JBL Tune 510BT белый',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Нет\n' +
        'микрофон: Да',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/jbl-tune-510bt-belyi-101420096/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3d/h52/33973207105566/jbl-tune-510bt-belyj-101420096-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h3e/h06/33973209759774/jbl-tune-510bt-belyj-101420096-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h99/he7/33973212381214/jbl-tune-510bt-belyj-101420096-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/had/h60/33973214969886/jbl-tune-510bt-belyj-101420096-4-Container.jpg']

    },
    {
      no: 9,
      id: "marshall-major-iv-chernyi-102138144/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6a/hd9/44876126093342/marshall-major-iv-102138144-3-Container.jpg',
      name: 'Наушники Marshall Major IV черный',
      description: 'тип: гарнитура\n' +
        'вид: накладные\n' +
        'подключение: беспроводное\n' +
        'тип акустического оформления: закрытые\n' +
        'тип крепления: оголовье\n' +
        'система активного шумоподавления: Нет\n' +
        'микрофон: Да',
      rating: 4.9,
      link: 'https://kaspi.kz/shop/p/marshall-major-iv-chernyi-102138144/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h6a/hd9/44876126093342/marshall-major-iv-102138144-3-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h17/h84/44876124127262/marshall-major-iv-102138144-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h2a/h24/44876125110302/marshall-major-iv-102138144-2-Container.jpg']

    },
    {
      no: 10,
      id: "jandeks-stantsija-mini-2-s-chasami-belyi-102580001/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5c/h05/46546975817758/yandeks-novaya-stantsiya-mini-s-chasami-seryi-102580001-1.jpg',
      name: 'Умная колонка Яндекс Станция Мини 2 с часами белый',
      description: 'суммарная мощность: 10 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Алиса\n' +
        'поддерживаемый язык: русский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 3.4,
      link: 'https://kaspi.kz/shop/p/jandeks-stantsija-mini-2-s-chasami-belyi-102580001/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h5c/h05/46546975817758/yandeks-novaya-stantsiya-mini-s-chasami-seryi-102580001-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h31/h79/46546976374814/yandeks-novaya-stantsiya-mini-s-chasami-seryi-102580001-2.jpg']

    },
    {
      no: 11,
      id: "jandeks-stantsija-maks-sinii-101165296/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf3/hd3/51046001246238/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-1.jpg',
      name: 'Умная колонка Яндекс Станция Макс синий',
      description: 'суммарная мощность: 65 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Алиса\n' +
        'поддерживаемый язык: русский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 4.7,
      link: 'https://kaspi.kz/shop/p/jandeks-stantsija-maks-sinii-101165296/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf3/hd3/51046001246238/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-1.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hf9/h96/51046001639454/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-3.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hd7/h54/51046001836062/yandeks-stantsiya-maks-s-alisoi-sinii-101165296-4.jpg']

    },
    {
      no: 12,
      id: "apple-homepod-mini-chernyi-100983175/?c=750000000#!/item",
      image: 'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h19/h04/52127953616926/apple-homepod-mini-cernyj-100983175-1-Container.jpg',
      name: 'Умная колонка Apple HomePod mini черный',
      description: 'суммарная мощность: 20 Вт\n' +
        'управление умным домом: Да\n' +
        'голосовой помощник: Apple Siri\n' +
        'поддерживаемый язык: английский\n' +
        'поддержка Wi-Fi: Да\n' +
        'поддержка Bluetooth: Да',
      rating: 5.0,
      link: 'https://kaspi.kz/shop/p/apple-homepod-mini-chernyi-100983175/?c=750000000#!/item',
      images: ['https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/h19/h04/52127953616926/apple-homepod-mini-cernyj-100983175-1-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hca/hcc/52127953846302/apple-homepod-mini-cernyj-100983175-2-Container.jpg',
        'https://resources.cdn-kaspi.kz/shop/medias/sys_master/images/images/hdb/hb7/51081275244574/apple-homepod-mini-cernyj-100983175-3-Container.jpg']

    },
  ];
  onGalleryImageClick(product: Product,image: string) {
    product.image = image;
  }
  getStarRating(rating: number): string[] {
    const starCount = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const stars: string[] = [];
    for (let i = 0; i < starCount; i++) {
      stars.push('full');
    }
    if (hasHalfStar) {
      stars.push('half');
    }
    while (stars.length < 5) {
      stars.push('empty');
    }
    return stars;
  }


}
