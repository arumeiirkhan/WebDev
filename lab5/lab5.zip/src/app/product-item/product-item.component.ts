import {Component, Input} from '@angular/core';
@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent {
  @Input() product: any;
  onGalleryImageClick(image: string) {
    this.product.image = image;
  }
  getStarRating(rating: number): string[] {
    const starCount = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const stars: string[] = [];
    for (let i = 0; i < starCount; i++) {
      stars.push('full');
    }
    if (hasHalfStar) {
      stars.push('half');
    }
    while (stars.length < 5) {
      stars.push('empty');
    }
    return stars;
  }
  incrementLikes() {
    this.product.likes++;
  }
  removeItem() {
    this.product.hidden = true;
  }
}
